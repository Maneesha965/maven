package com.infy.exception;

public class InfyMartException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InfyMartException(String message) {
		super(message);
	}

}