package com.infy.LoanEligibility;


public class LoanEligibility
{
	
	private String name;
	private int customerId;
	private String contact;
	private int creditScore;
	private int requiredLoanAmount;
	private char isLoanAllocated;
	public LoanEligibility(String name, int customerId, String contact, int creditScore, int requiredLoanAmount,
			char isLoanAllocated) {
		super();
		this.name = name;
		this.customerId = customerId;
		this.contact = contact;
		this.creditScore = creditScore;
		this.requiredLoanAmount = requiredLoanAmount;
		this.isLoanAllocated = isLoanAllocated;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public int getCreditScore() {
		return creditScore;
	}
	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}
	public int getRequiredLoanAmount() {
		return requiredLoanAmount;
	}
	public void setRequiredLoanAmount(int requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}
	public char getIsLoanAllocated() {
		return isLoanAllocated;
	}
	public void setIsLoanAllocated(char isLoanAllocated) {
		this.isLoanAllocated = isLoanAllocated;
	}
	public boolean isEligibleForLoan() {
        if(isLoanAllocated=='Y'||isLoanAllocated=='y') {
         	System.out.println("you are not eligibile for loan because already loan was allocated");
        	return false;
        }
        	else {
        		System.out.println("you are eligibile for loan!!!");
        	return true;
        	}
        }
	 public void applyForLoan() {
	        if (creditScore<=600) {
	            System.out.println("Sorry!!!!your credit score is very low can't allocate loan");
	        }else if(creditScore>=600&&creditScore<=750){
	        	System.out.println("congratulation....... your loan sanctioned");
	        	}
	        else if(creditScore>=750&&creditScore<=850) {
	        	System.out.println("congratulation........ your loan sanctioned");
	        }
	        else if(creditScore>800) {
	        	System.out.println("congratulation............ your loan sanctioned");
	        }

	 }   
	 
}
