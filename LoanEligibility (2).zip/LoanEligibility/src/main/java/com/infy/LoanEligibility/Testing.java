package com.infy.LoanEligibility;



public class Testing {

	public static void main(String[] args) {
		
		 LoanEligibility l1=new LoanEligibility("Tom",1001,"9876543123",752,500000,'N');
		 LoanEligibility l2=new LoanEligibility("Mathew",1002,"9876543134",500,300000,'y');
		 l1.isEligibleForLoan();
		 l1.applyForLoan();
		 System.out.println("-----------");
		 l2.isEligibleForLoan();
		 l2.applyForLoan();
		 
	}

}
